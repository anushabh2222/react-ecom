*create a react app using terminal by following steps
.create a one folder 
.in terminal type *create-react-app myprog(myprog is a filename)
.in terminal type *cd myprog(changing to myprog directory)
.npm start
*the react project is ready
*by that node modules,package.json,package lock json got created
*you can change the src and public files for doing projects
