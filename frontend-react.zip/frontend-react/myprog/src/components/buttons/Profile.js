// import React from 'react'
// import Login1 from './Login';
// import Signup1 from './Signup';

// const Profile = () => {

// return(
//     <li class="nav-item dropdown">
//     <a class="nav-link dropdown-toggle" href="/loan" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//       Loan
//     </a>
//     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
//       <li><a class="dropdown-item"><Login1/></a></li>
//       <li><hr class="dropdown-divider"></hr></li>
//       <li><a class="dropdown-item" ><Signup1/></a></li>
//       <li><hr class="dropdown-divider"/></li>
//       <li><a class="dropdown-item" href="/medicalloan">Medicalloan</a></li>
//     </ul>
//   </li>

// );

// }



// export default Profile;